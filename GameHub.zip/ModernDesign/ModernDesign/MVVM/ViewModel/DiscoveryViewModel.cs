﻿namespace ModernDesign.MVVM.ViewModel
{
    internal class DiscoveryViewModel
    {
    }
}
