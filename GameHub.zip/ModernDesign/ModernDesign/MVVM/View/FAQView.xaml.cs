﻿namespace ModernDesign.MVVM.View
{
    /// <summary>
    /// Interaction logic for FAQView.xaml
    /// </summary>
    public partial class FAQView
    {
        public FAQView()
        {
            InitializeComponent();
        }
    }
}
