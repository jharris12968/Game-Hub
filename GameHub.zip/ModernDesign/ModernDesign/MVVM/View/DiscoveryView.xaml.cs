﻿namespace ModernDesign.MVVM.View
{
    /// <summary>
    /// Interaction logic for DiscoveryView.xaml
    /// </summary>
    public partial class DiscoveryView
    {
        public DiscoveryView()
        {
            InitializeComponent();
        }
    }
}
